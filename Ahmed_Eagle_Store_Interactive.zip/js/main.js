// تطبيق كامل SPA باستخدام JavaScript
import { initApp } from './modules/app.js';
document.addEventListener('DOMContentLoaded', initApp);