// إدارة الواجهة والتفاعل الكامل
export function initApp() {
  const app = document.getElementById('app');
  app.innerHTML = `
    <header>
      <h1>مرحبا بك في Ahmed 🦅⚡</h1>
      <nav>
        <button onclick="showProducts()">منتجات</button>
        <button onclick="showCart()">السلة</button>
        <button onclick="showWishlist()">المفضلة</button>
        <button onclick="showLogin()">تسجيل دخول</button>
      </nav>
    </header>
    <main id="main-section"></main>
  `;
  window.showProducts = showProducts;
  window.showCart = showCart;
  window.showWishlist = showWishlist;
  window.showLogin = showLogin;
  showProducts();
}

function showProducts() {
  document.getElementById('main-section').innerHTML = '<h2>📦 المنتجات التفاعلية</h2>';
}
function showCart() {
  document.getElementById('main-section').innerHTML = '<h2>🛒 عربة الشراء</h2>';
}
function showWishlist() {
  document.getElementById('main-section').innerHTML = '<h2>❤️ المفضلة</h2>';
}
function showLogin() {
  document.getElementById('main-section').innerHTML = '<h2>🔐 تسجيل الدخول</h2>';
}